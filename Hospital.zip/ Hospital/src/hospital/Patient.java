
package hospital;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author JAWAHER
 */
public class Patient implements formation {
   private int ID;
   private String Name;
   private String Address;
   private long MobileNumber;
   private String Type;
   private String Email;
   private String dctor;
   private int age;
   private List<Service> Services=new ArrayList<>();;

   
   public Patient(int id,String name,  String address, long mobileNumber, String type, String email,String dctor, int age) {
       this.ID = id;
       this.Name = name;
       this.Address = address;
       this.MobileNumber = mobileNumber;
       this.Type = type;
       this.Email = email;
       this.dctor=dctor;
       this.age= age;
      // this.Services = new ArrayList<>();
   }

    public String getDctor() {
        return dctor;
    }

    public int getAge() {
        return age;
    }

    public void setDctor(String dctor) {
        this.dctor = dctor;
    }
   

   @Override
   public int getId() {
       return ID;
   }

   @Override
    public void setID(int ID) {
        this.ID = ID;
    }

   public String getName() {
       return Name;
   }

   public String getAddress() {
       return Address;
   }

   public long getMobileNumber() {
       return MobileNumber;
   }

   public String getType() {
       return Type;
   }

   public String getEmail() {
       return Email;
   }

   public List<Service> getServices() {
       return Services;
   }

   public void addService(Service service) {
       Services.add(service);
   }
//    public double diccount( Patient pat){ 
//      Scanner scan=new Scanner(System.in);
////       System.out.println("Enter patient Id: ");
////              
////               
////               int pId = scan.nextInt();
////               System.out.println("Enter Service Name: ");
////               String serviceName = scan.next();
////              // System.out.println("Enter Service Price: ");
////             double servicePrice = scan.nextDouble();
////            //  Patient pat = findPatientById(pId);
//////               if (pat == null) {
//////                 System.out.println("Patient not found");
//////               }
////               
////                   if (pat.getType().equalsIgnoreCase("A")) {
////                   return servicePrice -= (servicePrice * 25) / 100;
////                   } 
////                    
//                    
//                                
//                  
//    //               pat.addService(new Service(serviceId++, serviceName, servicePrice));
//  }
    
               @Override
   public String toString() {
       return "Patient id: "+ID+"  ,patient name: "+Name+"patient age : "+age+", Address: "+Address+ ", Mobile Number: "+ MobileNumber+" ,typy : "+Type+"  ,emil:  "+Email+", Dctor of the patient :" +dctor+", the  Services is :  "+Services.toString();
                                                                                                                 
   }
   }
    

  
    
