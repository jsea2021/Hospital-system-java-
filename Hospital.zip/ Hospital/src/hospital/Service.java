
package hospital;

import java.util.Scanner;

/**
 *
 * @author JAWAHER
 */
public class Service implements formation {
   private int Id;
   private String name;
   private double price;

  
   public Service(int Id, String name, double price) {
       this.Id = Id;
       this.name = name;
       this.price = price;
   }

  
   @Override
  public int getId() {
       return Id;
   }

   @Override
    public void setID(int ID) {
        this.Id = Id;
    }

  
   @Override
   public String getName() {
       return name;
   }

  
   public double getPrice() {
       return price;
   }

   @Override
   public String toString() {
       return "Service id:"+ Id+ ", Service Name: " +name+" , Price: "+price;
   }
  
    
}
