
package hospital;

import java.util.ArrayList;
import java.util.Scanner;
  
/**
 *
 * @author JAWAHER
 */

public class Hospital {
 
 
  static int doctorId= 0;
  static int patientId = 0;
  static int serviceId = 0;
   static int nursesId = 0;
   /**
   * The main method.
   *
   * @param args the arguments
   */
   public static void main(String[] args) {
        ArrayList<Employee> staffs=new ArrayList<>();;
        ArrayList<Employee>  doctors= new ArrayList<>();
        ArrayList<Patient>  patients = new ArrayList<>() ; 
        ArrayList<Employee> nurse= new ArrayList<>();
     

      Employee a1= new AdministrationStaff (3345,"ahmd",  "makkah", 67895432, 1000, "ahmd@email.com", "admin" );
      staffs.add(a1);
     Employee a2= new AdministrationStaff (3345,"khaled",  "makkah", 8797638, 2000, "khalid@email.com", "admin Staff " );
      staffs.add(a2);
     Employee a3= new AdministrationStaff ( 3345,"esa", "makkah", 67865438, 3000, "esa@email.com", "admin Hospital" );
      staffs.add(a3);
     
       int choies = 0;
   //     boolean b=true;
//        int e=0;
     //  do{
     //  try{
        System.out.println("******Lets go to start my first project ******");
         Scanner s= new Scanner(System.in);
           boolean c= true;
           
       do {
     
           System.out.println("Enter your name of Sttaf: ");
           String st= s.next();
                 if(st.equalsIgnoreCase(a1.getName())||st.equalsIgnoreCase(a2.getName())||st.equalsIgnoreCase(a3.getName())){
            System.out.println("Hi ( miss/ms ) : "+st);  
                  c= false;
                     }
           if (c) 
           {
               System.out.println("***Please try again Staff not found!!!***");
           }//end if 2
       }//end do
       while (c);
     //   b=false;
      // }
       //catch(Exception e){
        //   System.out.println("Inviled  input" );
      // }
     //  }while(b);
       do {
       System.out.println("");
       System.out.println("Enter your choies or enter choies 9 to exit!");
       System.out.println("1. Add Nurses");
       System.out.println("2. Add Doctor");
       System.out.println("3. Add Patient");
       System.out.println("4. Add Service");
       System.out.println("5. Print the patients bill");
       System.out.println("6. Print doctor information");
       System.out.println("7. Print patient information");
       System.out.println("8. Print nurses information");
       System.out.println("9. Exit");
         System.out.println("");
        choies = s.nextInt(); 
       System.out.println("");
     
         
     
          
           switch (choies) {
             case 1:
              System.out.println("Enter nurse Name: ");
               String nuName = s.next();
              System.out.println("Enter nurse Address: ");
             String nuAddress = s.next();
             System.out.println("Enter nurse Mobile number: ");
              long nuMobileNo = s.nextLong();
              System.out.println("Enter nurse salary: ");
             double nusalary = s.nextDouble();
             System.out.println("Enter nurse email: ");
              String nuEmail = s.next();
              System.out.println("Enter nurse Rank: ");
              String nuRank = s.next();
                System.out.println("Enter nurse speciality : ");
                String speciality=s.next();

              nurse.add(new Nurse( ++nursesId,nuName, nuAddress, nuMobileNo, nusalary, nuEmail, nuRank,speciality));
               System.out.println("^^^End add nurses^^^");
              System.out.println("you add right now **"+nursesId+" **nurses");
              System.out.println("**////////////////////////////////////////////** ");
          
               break;     
           case 2:
               System.out.println("Enter Doctor Name: ");
               String Name = s.next();
                System.out.println("Enter Doctor clinc : ");
                String clinc=s.next();
               System.out.println("Enter Doctor Address: ");
               String Address = s.next();
               System.out.println("Enter Doctor Mobile number: ");
               long MobileNo = s.nextLong();
               System.out.println("Enter Doctor salary: ");
               double salary = s.nextDouble();
               System.out.println("Enter Doctor email: ");
               String Email = s.next();
               System.out.println("Enter Doctor Rank: ");
               String Rank = s.next();
               System.out.println("Enter Doctor speciality: ");
               String Speciality = s.next();
               System.out.println("Enter ID of special nurse:  ");
              
               int specialNurse = s.nextInt();
                 String  namenurse="";
             for (Employee d :nurse) { 
                if (d.getId()== specialNurse){
                 namenurse=d.getName();
               doctors.add(new Doctor(++doctorId,Name,  Address, MobileNo, salary, Email, Rank, Speciality, namenurse,clinc));
                System.out.println("^^^End add dector^^^");
                
                break;
               
                }
                
                else{
               
                   System.out.println("nurse of the dctor not found "); 
                }//else
                }//end for
              
                
              
          
              System.out.println("you add right now **"+doctorId+" **dectors");
               System.out.println("**////////////////////////////////////////////** ");
          
               break; 
             
          
           case 3:

               System.out.println("Enter Patient Name: ");
               String patientName = s.next();
                System.out.println("Enter Patient age: ");
                int age=s.nextInt();
               System.out.println("Enter Patient Address: ");
               String patientAddress = s.next();
               System.out.println("Enter Patient Mobile number: ");
               long patientMobileNo = s.nextLong();
               System.out.println("Enter Patient Type A or B: ");
               String patientType = s.next();
               System.out.println("Enter Patient email: ");
               String patientEmail = s.next();
               System.out.println("Enter  id of Dctor for patient ");
               int patientD=s.nextInt();
               String nameadctor="";
        
               for (Employee doc : doctors) { 
                if (doc.getId()== patientD){
               nameadctor=doc.getName();
                patients.add(new Patient(++patientId,patientName,  patientAddress, patientMobileNo, patientType, patientEmail, nameadctor,age));
                //System.out.println(namedctor);
                  System.out.println("^^^End add patient^^^");
                break;
                }
                else
                   System.out.println("dctor of the patient not found ");  
                }
                System.out.println("you add right now **"+patientId+" **patients");
               System.out.println("**//////////////////////////////////////////// **");
               

               break;
          
           case 4:
               System.out.println("Enter patient Id: ");
               int pId = s.nextInt();
               System.out.println("Enter Service Name: ");
               String serviceName = s.next();
               System.out.println("Enter Service Price: ");
               double Price = s.nextDouble();     
              
               Patient pat;
             for (Patient p : patients) {
                    if (p.getId() == pId)
                    {
                          pat=p; 
                    
//                           if (pat == null)
//                           {
//                  System.out.println("Patient not found");
//                           }//if اللي جوا
//             else 
                          // {
                               
           if (pat.getType().equalsIgnoreCase("a")) {
                   Price -= (Price * 25) / 100;
                
               }//end if الصغيره
            pat.addService(new Service(++serviceId, serviceName, Price));
                
//                            }//end else
                             if (pat == null)
                           {
                  System.out.println("Patient not found");
                           }//if اللي جوا
                             // pat.addService(new Service(++serviceId, serviceName, Price));
                     }// end if 1
                      
                      }//end for الكبيره
                System.out.println("the patient have now **"+serviceId+"**  service"); 
//                System.out.println("/////Enter your choies///");
           break;
            
           case 5:
              
               System.out.println("Enter patient Id: ");
               int paId = s.nextInt();
               double total = 0;
              
             
                          
                for (Patient p : patients)
                {
                      if (p.getId() == paId)
                      {
             for (Service se : p.getServices())
              { 
                       total = total+se.getPrice();
                   
               } //end for 2
              System.out.println("Patient name : "+p.getName());
              System.out.println("Patient age  : "+p.getAge());
              System.out.println("patient ID : " +p.getId());
              System.out.println("Patient Type : "+p.getType());
              System.out.println("Patient Service : "+p.getServices());
              System.out.println("Patient's Bill is : " + total);
              break;
                       }//end if 1
                   
             else if (p.getId()!=paId) 
              {
                   System.out.println("Patient not found");
               }//end if 2
             
                }//end for 1

               break;

           case 6:
               System.out.println("Enter doctor id:");
               int docId = s.nextInt();
//              
                for (Employee doc : doctors) {
                if (doc.getId() == docId)
                    {
                 System.out.println(doc.toString());
               break;
                    }
              
               
               else {
                     System.out.println("Doctor not found");
//                  
                     }
           
                }
               break;

           case 7:
               System.out.println("Enter patient Id: ");
               int patId = s.nextInt();
             
               for (Patient p : patients) 
               {
               if (p.getId() == patId) 
               {
              System.out.println(p.toString());
              break;
               }//if
         
              else if (p.getId() !=patId ) 
              {
                   System.out.println("Patient not found");
               }//
              
               }//for
               
               break;
           case 8:
               int nuId=0;
               boolean b=true;
               do{
           try {
      
        System.out.println("Enter nurse id:");
         String nuI = s.next();
          nuId =Integer.parseInt(nuI);
            for (Employee doc :nurse ) {
                if (doc.getId() == nuId)
                    {
                 System.out.println(doc.toString());
                break;
                    }
               
               else {
                     System.out.println("nurses not found");
//                  
                     }
           
                }
        b=false;
         }
             
          catch( Exception e){
       System.out.println(" please try again ,Inviled  input!" );
      
          }
       
           
       }  while(b); 
          

               break;

           case 9:
               
                System.out.println("you have **"+doctorId+" **dectors");
                System.out.println("you have **"+patientId+" **patients");
                System.out.println("you have **"+nursesId+" **nerses");
               break;

           default:
               System.out.println("***Please try again Invalid Input*** ");
               break;
           }
       } while (choies!= 9);

    

   }
      
       
   }//end class

  
  
    
  
    

