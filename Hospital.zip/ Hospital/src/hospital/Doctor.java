
package hospital;

/**
 *
 * @author JAWAHER
 */
public class Doctor extends Employee  {
      private String SpecialNurse;
      private String specialty;
      private String rank;
       private Nurse nurse;
      private  String clinc;
   public Doctor(int id,String name,String address,long mobileNumber,double salary, String email, String rank, String specialty, String specialNurse, String clinc) {
       super(id, name,address,mobileNumber,   salary, email);
       this.SpecialNurse = specialNurse;
       this.rank=rank;
       this.specialty=specialty;
       this.clinc=  clinc;
   }

   
   public String  getSpecialNurse() {
       return SpecialNurse;
   }

   @Override
   public String toString() {
       return super.toString()+"  ,specialty : "+ specialty+", rank : "+rank+" , the clinc of dctor : " +clinc+ " ,specialNurse :"+SpecialNurse;
   }

    
}
