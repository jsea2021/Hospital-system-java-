
package hospital;

/**
 *
 * @author JAWAHER
 */
public class AdministrationStaff extends Employee {
     private String Position;

  
   public AdministrationStaff( int id,String name,String address,long mobileNumber,   double salary, String email, String position) {
       super(id, name,address, mobileNumber , salary, email);
       this.Position = position;
   }

   
   public String getPosition() {
       return Position;
   }

   @Override
   public String toString() {
       return  super.toString()+" ,Position: " +Position;
   }

    
}
