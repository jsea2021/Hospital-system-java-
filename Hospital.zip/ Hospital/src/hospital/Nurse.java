/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

/**
 *
 * @author JAWAHER
 */
public class Nurse extends Employee {
    private String Rank;
   private String Specialty;
 
   
   public Nurse(int id, String name,String address,long mobileNumber,   double salary, String email, String rank, String specialty) {
       super(id, name,address,mobileNumber,   salary, email);
       this.Rank = rank;
       this.Specialty = specialty;
      
   }


  
   public String getRank() {
       return Rank;
   }

   
   public String getSpecialty() {
       return Specialty;
   }

   @Override
   public String toString() {
       return super.toString()+ "  ,specialty : "+Specialty+", rank : " +Rank  ;
   }
    
}
