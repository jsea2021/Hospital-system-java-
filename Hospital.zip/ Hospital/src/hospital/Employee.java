
package hospital;

/**
 *
 * @author JAWAHER
 */
public class Employee {
    private int ID;
   private String Name;
   private String Address;
   private long MobileNumber;
   private double Salary;
   private String Email;

  
   public Employee(int ID, String name,String address,long mobileNumber,   double salary, String email) {
       this.ID = ID;
       this.Name = name;
       this.Address = address;
       this.MobileNumber = mobileNumber;
       this.Salary = salary;
       this.Email = email;
   }

   
   public int getId() {
       return ID;
   }

   
   public String getName() {
       return Name;
   }

  
   public String getAddress() {
       return Address;
   }

  
   public long getMobileNumber() {
       return MobileNumber;
   }

   
   public double getSalary() {
       return Salary;
   }

   
   public String getEmail() {
       return Email;
   }

   @Override
   public String toString() {
       return "The Id is :"+ID+", the name: "+Name+", Address: "+Address+ ", Mobile Number:"+ MobileNumber+ ", Salary: "+Salary+ " , Email:"+  Email;
   }

    
}
